package com.radialbog.gamemode;

import org.bukkit.command.CommandExecutor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.permissions.Permission;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

import com.radialbog.gamemode.Commands.AllPlayers;
import com.radialbog.gamemode.Commands.Day;
import com.radialbog.gamemode.Commands.Gma;
import com.radialbog.gamemode.Commands.Gmc;
import com.radialbog.gamemode.Commands.Gms;
import com.radialbog.gamemode.Commands.Gmsp;
import com.radialbog.gamemode.Commands.Heal;
import com.radialbog.gamemode.Commands.KickGUI;
import com.radialbog.gamemode.Commands.Midday;
import com.radialbog.gamemode.Commands.Night;
import com.radialbog.gamemode.Commands.Rtp;
import com.radialbog.gamemode.Commands.SuperVanish;
import com.radialbog.gamemode.Commands.Vanish;


public class Main extends JavaPlugin implements Listener{
	public Permission gamemodesandmore = new Permission("gamemodesandmore");
	
	public void onEnable() {
		System.out.println("(!) Plugin 'Gamemodes And More' by 'Radialbog9' Enabled");
		PluginManager pm = getServer().getPluginManager();
		pm.addPermission(gamemodesandmore);
		this.getCommand("gmc").setExecutor((CommandExecutor)new Gmc());
		this.getCommand("gms").setExecutor((CommandExecutor)new Gms());
		this.getCommand("gma").setExecutor((CommandExecutor)new Gma());
		this.getCommand("gmsp").setExecutor((CommandExecutor)new Gmsp());
		this.getCommand("day").setExecutor((CommandExecutor)new Day());
		this.getCommand("midday").setExecutor((CommandExecutor)new Midday());
		this.getCommand("night").setExecutor((CommandExecutor)new Night());
		this.getCommand("wild").setExecutor((CommandExecutor)new Rtp()); 
		this.getCommand("rtp").setExecutor((CommandExecutor)new Rtp());
		this.getCommand("heal").setExecutor((CommandExecutor)new Heal());
		this.getCommand("allplayers").setExecutor((CommandExecutor)new AllPlayers());
		this.getCommand("vanish").setExecutor((CommandExecutor)new Vanish());
		this.getCommand("v").setExecutor((CommandExecutor)new Vanish());
		this.getCommand("supervanish").setExecutor((CommandExecutor)new SuperVanish());
		this.getCommand("sv").setExecutor((CommandExecutor)new SuperVanish());
		this.getCommand("kickg").setExecutor((CommandExecutor)new KickGUI());
		getServer().getPluginManager().registerEvents(this, this);
		}
	public void onDisable() {
		System.out.println("(!) Gamemodes And More Disabled!");
	}
	
	
	@SuppressWarnings("deprecation")
	@EventHandler
	public void onPlayerJoin(PlayerJoinEvent e) {
		Player player = e.getPlayer();
		for(Player p : Vanish.vanished) {
			if(!(player.hasPermission("gamemodesandmore.admin.seevanish"))) {
				player.hidePlayer(p);	
			}
			else {
				player.showPlayer(p);
			}
		}
		for(Player p : SuperVanish.supervanished) {
			if(!(player.hasPermission("gamemodesandmore.op.seesupervanish"))) {
				player.hidePlayer(p);	
			}
			else {
				player.showPlayer(p);
			}
		}
		for(Player p : AllPlayers.playershidden) {
			p.hidePlayer(player);
		}
	}
}
