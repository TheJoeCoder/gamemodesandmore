package com.radialbog.gamemode.Commands;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class KickGUI implements CommandExecutor{

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if(sender instanceof Player) {
			Player player = (Player) sender;
			if(player.hasPermission("gamemodesandmore.admin.kickall")) {
				GUIHandler.kickguioneshow(player);
				return true;
			} else {
				player.sendMessage(ChatColor.RED + "Sorry, you can't  run this command. If you believe this is an error, please contact an Admin.");
				return true;
			}
		} else {
			sender.sendMessage("Sorry, you can't kick players from the console yet.");
			return true;
		}
	}
	
}
