package com.radialbog.gamemode.Commands;

import java.util.Arrays;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.DyeColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.material.Wool;
import org.bukkit.plugin.Plugin;

public class GUIHandler implements Listener {
	private static Inventory kickguione;
	private ItemStack y, n;
	
	public void kickone(Plugin pl) {
		kickguione = Bukkit.getServer().createInventory(null, 45, "Kick GUI");
		
		y = createItem(DyeColor.GREEN, ChatColor.GREEN + "Yes", "Kicks All Players");
		n = createItem(DyeColor.RED, ChatColor.RED + "No", "Doesn't kick all players");
		
		kickguione.setItem(31, y);
		kickguione.setItem(33, n);
		
		Bukkit.getServer().getPluginManager().registerEvents(this, pl);
	}
	
	
	
	private ItemStack createItem(DyeColor dc, String name, String lore) {
		@SuppressWarnings("deprecation")
		ItemStack i = new Wool(dc).toItemStack(1);
		ItemMeta im = i.getItemMeta();
		im.setDisplayName(name);
		im.setLore(Arrays.asList(lore));
		i.setItemMeta(im);
		return i;
		
	}
	public static void kickguioneshow(Player p) {
		p.openInventory(kickguione);
	}
	
	@EventHandler
	public void onInventoryClick(InventoryClickEvent e) {
		if(!(e.getInventory().equals(kickguione))) return;
		if (e.getCurrentItem().getItemMeta().getDisplayName().contains("Yes")) {
			e.getWhoClicked().closeInventory();
			for (Player p: Bukkit.getOnlinePlayers()) {
				if (!(p.hasPermission("gamemodesandmore.admin.unkickable"))) {
					p.kickPlayer(ChatColor.RED + "Sorry, you have been kicked.\nPlease try again Later.");
				}
			}
		}
		if(e.getCurrentItem().getItemMeta().getDisplayName().contains("No")) {
			e.getWhoClicked().closeInventory();
		}
	}
}
//31 and 33