package com.radialbog.gamemode.Commands;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class Gmsp implements CommandExecutor {
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if(sender instanceof Player) {
			Player player = (Player) sender;
			if(player.hasPermission("gamemodesandmore.gamemodeswitch.spectator")) {
				player.setGameMode(GameMode.SPECTATOR);
				player.sendMessage(ChatColor.GOLD + "You Are Now In Gamemode " + ChatColor.DARK_RED + "Spectator");
			} else {
				player.sendMessage(ChatColor.RED + "Sorry, but you cannot use this command. If you believe this is an error, please contact a moderator of this server.");
			}
		}
		else {
			sender.sendMessage("You Can't Use This!!!");
		}
		return true;
	}
}
