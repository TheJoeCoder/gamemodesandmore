package com.radialbog.gamemode.Commands;

import org.bukkit.ChatColor;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class Night implements CommandExecutor{
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		Player player = (Player) sender;
		World world = player.getWorld();
		if(player.hasPermission("gamemodesandmore.time.night")) {
			world.setTime(13000);
			player.sendMessage(ChatColor.GOLD + "Set The Time To " + ChatColor.DARK_RED + "13000" + ChatColor.GOLD +" or " + ChatColor.DARK_RED + "7:00pm" + ChatColor.GOLD + " or " + ChatColor.DARK_RED + "Night" + ChatColor.GOLD + ".");
			return true;
		} else {
			player.sendMessage(ChatColor.DARK_RED + "Sorry, You Cannot Use This Command.");
		}
		return true;
	}
}
