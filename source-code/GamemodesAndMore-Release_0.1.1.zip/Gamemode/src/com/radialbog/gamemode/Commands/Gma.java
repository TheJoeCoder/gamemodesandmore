package com.radialbog.gamemode.Commands;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class Gma implements CommandExecutor {
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		Player player = (Player) sender;
		if(sender instanceof Player) {
			if(player.hasPermission("gamemodesandmore.gamemodeswitch.adventure")) {
				player.setGameMode(GameMode.ADVENTURE);
				player.sendMessage(ChatColor.GOLD + "You Are Now In Gamemode " + ChatColor.DARK_RED + "Adventure");
			}
		}
		else {
			sender.sendMessage("You Can't Use This!!!");
		}
		return true;
	}
}
