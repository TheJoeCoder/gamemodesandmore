package com.radialbog.gamemode;

import org.bukkit.ChatColor;
import org.bukkit.command.CommandExecutor;
import org.bukkit.permissions.Permission;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

import com.radialbog.gamemode.Commands.AllPlayers;
import com.radialbog.gamemode.Commands.Day;
import com.radialbog.gamemode.Commands.Gma;
import com.radialbog.gamemode.Commands.Gmc;
import com.radialbog.gamemode.Commands.Gms;
import com.radialbog.gamemode.Commands.Gmsp;
import com.radialbog.gamemode.Commands.Heal;
import com.radialbog.gamemode.Commands.Midday;
import com.radialbog.gamemode.Commands.Night;
import com.radialbog.gamemode.Commands.Rtp;
import com.radialbog.gamemode.Commands.Wild;


public class Main extends JavaPlugin{
	public Permission gamemodesandmore = new Permission("gamemodesandmore");
	public void onEnable() {
		System.out.println(ChatColor.GOLD + "(!) Plugin 'Gamemodes And More' by 'Radialbog9' Enabled");
		PluginManager pm = getServer().getPluginManager();
		pm.addPermission(gamemodesandmore);
		this.getCommand("gmc").setExecutor((CommandExecutor)new Gmc());
		this.getCommand("gms").setExecutor((CommandExecutor)new Gms());
		this.getCommand("gma").setExecutor((CommandExecutor)new Gma());
		this.getCommand("gmsp").setExecutor((CommandExecutor)new Gmsp());
		this.getCommand("day").setExecutor((CommandExecutor)new Day());
		this.getCommand("midday").setExecutor((CommandExecutor)new Midday());
		this.getCommand("night").setExecutor((CommandExecutor)new Night());
		this.getCommand("wild").setExecutor((CommandExecutor)new Wild()); 
		this.getCommand("rtp").setExecutor((CommandExecutor)new Rtp());
		this.getCommand("heal").setExecutor((CommandExecutor)new Heal());
		this.getCommand("allplayers").setExecutor((CommandExecutor)new AllPlayers());
	}
	public void onDisable() {
		System.out.println(ChatColor.GOLD + "(!) Gamemodes And More Disabled!");
	}
}
