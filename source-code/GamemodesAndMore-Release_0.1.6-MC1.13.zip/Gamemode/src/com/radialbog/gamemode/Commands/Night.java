package com.radialbog.gamemode.Commands;

import org.bukkit.ChatColor;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class Night implements CommandExecutor{
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if(sender instanceof Player) {
		Player player = (Player) sender;
		World world = player.getWorld();
		if(player.hasPermission("gamemodesandmore.time.night")) {
			world.setTime(13000);
			player.sendMessage(ChatColor.GOLD + "Set The Time To " + ChatColor.DARK_RED + "13000" + ChatColor.GOLD +" or " + ChatColor.DARK_RED + "7:00pm" + ChatColor.GOLD + " or " + ChatColor.DARK_RED + "Night" + ChatColor.GOLD + ".");
			return true;
		} else {
			player.sendMessage(ChatColor.RED + "Sorry, but you cannot use this command. If you believe this is an error, please contact a moderator of this server.");
			return true;
		}
		} else {
			sender.sendMessage("Oops! you can't use this command from the console!");
			return true;
		}
	}
}
