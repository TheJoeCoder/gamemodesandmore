package com.radialbog.gamemode.Commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class KickAll implements CommandExecutor{

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if(sender instanceof Player) {
			Player player = (Player) sender;
			if(player.hasPermission("gamemodesandmore.admin.kickall")) {
				for(Player p : Bukkit.getOnlinePlayers()) {
					if (!(p.hasPermission("gamemodesandmore.admin.unkickable"))) {
						p.kickPlayer(ChatColor.RED + "Sorry, you have been kicked.\nPlease try again Later.");
					}
				}
				return true;
			} else {
				player.sendMessage(ChatColor.RED + "Sorry, you can't  run this command. If you believe this is an error, please contact an Admin.");
				return true;
			}
		} else {
			for(Player p : Bukkit.getOnlinePlayers()) {
				if (!(p.hasPermission("gamemodesandmore.admin.unkickable"))) {
					p.kickPlayer(ChatColor.RED + "Sorry, you have been kicked.\nPlease try again Later.");
				}
			}
			return true;
		}
	}
	
	
}
