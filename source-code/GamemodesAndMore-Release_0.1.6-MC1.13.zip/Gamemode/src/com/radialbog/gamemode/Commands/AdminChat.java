package com.radialbog.gamemode.Commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class AdminChat implements CommandExecutor {

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if (sender instanceof Player) {
			//sender is a player
			Player player = (Player) sender;
					
			if (player.hasPermission("gamemodesandmore.admin.adminchat.post")) {
				//player has permission
				if (!(args.length >= 1)) {
					//player typed in arguments
					
					String finalstring = "";
					for (int i = 2; i < args.length - 1; i++) {
					    finalstring += args[i] + ' ';
					}
					finalstring += args[args.length - 1];
					
					for(Player p : Bukkit.getOnlinePlayers()) {
						if(p.hasPermission("gamemodesandmore.admin.adminchat.see")) {
							p.sendMessage(ChatColor.RED + "[Admin Only] " + ChatColor.BLUE + player + ": " + ChatColor.RED + finalstring);
						}
					}
					return true;
				}else {
					//player typed no args
					player.sendMessage(ChatColor.DARK_RED + "ERROR. Incorrect use of arguments.\n" + ChatColor.GREEN + "Correct use of arguments:\n" + ChatColor.DARK_GREEN + "/ao <message>");
					return true;
				}
				
			} else{
				//player not have permission
				player.sendMessage(ChatColor.RED + "Sorry, but you cannot use this command. If you believe this is an error, please contact a moderator of this server.");
				return true;
			}
			
		}else {
			//sender is console
			if (!(args.length >= 1)) {
				//console typed in arguments
				
				String finalstring = "";
				for (int i = 2; i < args.length - 1; i++) {
				    finalstring += args[i] + ' ';
				}
				finalstring += args[args.length - 1];
				
				for(Player p : Bukkit.getOnlinePlayers()) {
					if(p.hasPermission("gamemodesandmore.admin.adminchat.see")) {
						p.sendMessage(ChatColor.RED + "[Admin Only] " + ChatColor.BLUE + "CONSOLE: " + ChatColor.RED + finalstring);
					}
				}
				return true;
			}else {
				//console typed no args
				sender.sendMessage("ERROR. Incorrect use of arguments. Correct use of arguments: /ao <message>");
				return true;
			}
		}
	}

}
