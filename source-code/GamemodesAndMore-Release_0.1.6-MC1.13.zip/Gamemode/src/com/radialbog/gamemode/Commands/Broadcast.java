package com.radialbog.gamemode.Commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class Broadcast implements CommandExecutor{

	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if(sender instanceof Player) {
			//player executed it
			Player player = (Player) sender;
			if(player.hasPermission("gamemodesandmore.admin.broadcast")) {
				//player has permission
				if (!(args.length >= 1)) {
					// player hasn't typed in message
					player.sendMessage(ChatColor.RED + "Incorrect use of Arguments.\n" + ChatColor.GREEN + "Arguments: \n/broadcast <Message>");
					return true;
				} else {
					// player typed in  message
					String finalstring = "";
					for (int i = 2; i < args.length - 1; i++) {
					    finalstring += args[i] + ' ';
					}
					finalstring += args[args.length - 1];
					
					for(Player p : Bukkit.getOnlinePlayers()) {
						p.sendMessage(ChatColor.RED + "Broadcast " + ChatColor.WHITE + finalstring);
					}
					return true;
				}
			} else {
				//player has no permission
				player.sendMessage(ChatColor.RED + "Sorry, but you cannot use this command. If you believe this is an error, please contact a moderator of this server.");
				return true;
			}
			
		}else {
			// console executes it
			if (!(args.length == 1)) {
				// console hasn't typed in message
				sender.sendMessage("Incorrect use of Arguments. Arguments: \n/broadcast <Message>");
				return true;
			} else {
				// console typed in  message
				String finalstring = "";
				for (int i = 2; i < args.length - 1; i++) {
				    finalstring += args[i] + ' ';
				}
				finalstring += args[args.length - 1];
				
				for(Player p : Bukkit.getOnlinePlayers()) {
					p.sendMessage(ChatColor.RED + "Broadcast " + ChatColor.WHITE + finalstring);
				}
				return true;
			}
		}
		
	}

}
