package com.radialbog.gamemode.Commands;

import java.util.ArrayList;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class Vanish implements CommandExecutor {
	public static ArrayList<Player> vanished = new ArrayList<Player>();
	
	@SuppressWarnings("deprecation")
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if (sender instanceof Player) {
			Player player = (Player) sender;
			if(player.hasPermission("gamemodesandmore.admin.vanish")) {
				if(vanished.contains(player)) {
					//unvanish
					for(Player p : Bukkit.getOnlinePlayers()) {
						p.showPlayer(player);
					}
					vanished.remove(player);
					player.sendMessage(ChatColor.GREEN + "You are now unvanished!");
					return true;
				}
				else {
					//vanish
					for(Player p : Bukkit.getOnlinePlayers()) {
						if(!(p.hasPermission("gamemodesandmore.admin.seevanish")))
						p.hidePlayer(player);
						player.sendMessage(ChatColor.GREEN + "You are now in vanish!");
					}
					vanished.add(player);
					return true;
				}
			}
			else {
				player.sendMessage(ChatColor.RED + "Sorry, you cannot use this command. If you believe this is an error, please contact an administrator.");
				return true;
			}
		}
		else {
			sender.sendMessage("Sorry, but you cannot use this command.");
			return true;
		}
	}

}
