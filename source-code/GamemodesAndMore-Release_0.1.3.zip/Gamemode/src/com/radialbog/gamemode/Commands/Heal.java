package com.radialbog.gamemode.Commands;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class Heal implements CommandExecutor{
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		if (sender instanceof Player) {
			
		Player player = (Player) sender;
		
		if (args.length == 0) {
			//Player only typed '/heal' so lets heal them back!
			player.setHealth(20.0);
			} else {
			//Player typed something more
				Player target = (Player) Bukkit.getOnlinePlayers();
				if (target == null) {
					//Target is not online
					player.sendMessage(ChatColor.RED + "Player " + ChatColor.GOLD + args[0] + ChatColor.RED + " is not online!");
				} else {
					//Targets online
					player.sendMessage("You've healed " + args[0]);
					target.setHealth(20.0);
				}
			}
			return true;
		}
		else {
			sender.sendMessage("Sorry, but you can't use this!");
			return true;
		}
	}
}
