package com.radialbog.gamemode.Commands;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class Gms implements CommandExecutor {
	@Override
	public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
		Player player = (Player) sender;
		if(sender instanceof Player) {
			if(player.hasPermission("gamemodesandmore.gamemodeswitch.survival")) {
				player.setGameMode(GameMode.SURVIVAL);
				player.sendMessage(ChatColor.GOLD + "You Are Now In Gamemode " + ChatColor.DARK_RED + "Survival");
			}
		}
		else {
			sender.sendMessage("You Can't Use This!!!");
		}
		return true;
	}
}
